#include <stdio.h>
#include <stdlib.h>
#include "loader.h"
#include "mem.h"
#include "util.h"


void load_inst_to_mem(const char *buffer, const int index)
{
    int word;

    word = str_to_int(buffer);
    //printf("\n word: %d\n", word);
    mem_write_32(MEM_TEXT_START + index, word);
}

void load_data_to_mem(const char *buffer, const int index)
{
    uint32_t word;
    word = str_to_int(buffer);
    // printf("\n word: %d\n", word);
    // printf("\n index: %d\n", index);
    mem_write_32(MEM_DATA_START + index, word);
}

/**************************************************************/
/*                                                            */
/* TODO: Load program and service routines into mem.    */
/*                                                            */
/**************************************************************/
void load_program(char *program_filename) {
    FILE *prog;
    int i = 0;
    char buffer[33];

    //to notifying data & text segment size
    int text_size = 0;
    int data_size = 0;

    /* Open program file. */
    prog = fopen(program_filename, "r");

    if (prog == NULL) {
        printf("Error: Can't open program file %s\n", program_filename);
        exit(EXIT_FAILURE);
    }

    /* Read in the program. */
    // 1st: read the size of text section
    if (fgets(buffer, 33, prog) != NULL) {
        text_size = str_to_int(buffer);
        g_processor.input_insts = text_size/4;

    } else {
        printf("Error occured while loading %s\n", program_filename);
        exit(EXIT_FAILURE);
    }
    
    // 2nd: read the size of data section
    // TODO
    if (fgets(buffer, 33, prog) != NULL){
        //printf("\n buffer2: %s\n", buffer);
        //printf("\n data_size: %s\n", buffer);
        data_size = str_to_int(buffer);
    }

    // 3rd: load the text and data binary to memory
    // TODO
    
    for(int j =0; j < g_processor.input_insts; j++){
        if (fgets(buffer, 33, prog) != NULL){
            load_inst_to_mem(buffer, i);
            //printf("\n inst_buffer: %s\n", buffer);
            i += 4;
        }
    }
    int k = 0;
    for(int q = 0; q < data_size/4; q ++){
        
        if (fgets(buffer, 33, prog) != NULL){
           // printf("\n data_buffer: %s\n", buffer);
            load_data_to_mem(buffer, k);
            k += 4;
        }
    }
    fclose(prog);

    g_processor.pc = MEM_TEXT_START;
    g_processor.running = TRUE;
}
